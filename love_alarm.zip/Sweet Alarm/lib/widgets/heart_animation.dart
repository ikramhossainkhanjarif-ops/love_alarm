import 'dart:math';
import 'package:flutter/material.dart';

class HeartAnimation extends StatefulWidget {
  const HeartAnimation({Key? key}) : super(key: key);
  @override
  _HeartAnimationState createState() => _HeartAnimationState();
}

class _HeartAnimationState extends State<HeartAnimation> with TickerProviderStateMixin {
  final List<Widget> _hearts = [];
  late final AnimationController _spawnController;

  @override
  void initState() {
    super.initState();
    _spawnController = AnimationController(vsync: this, duration: const Duration(milliseconds: 600))
      ..addListener(() {
        if (mounted && Random().nextDouble() < 0.3) {
          setState(() {
            _hearts.add(const _SingleHeart());
          });
        }
      })..repeat();
  }

  @override
  void dispose() {
    _spawnController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(children: _hearts);
  }
}

class _SingleHeart extends StatefulWidget {
  const _SingleHeart({Key? key}) : super(key: key);
  @override
  __SingleHeartState createState() => __SingleHeartState();
}

class __SingleHeartState extends State<_SingleHeart> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  double leftOffset = Random().nextDouble() * 360;
  double size = Random().nextDouble() * 20 + 15;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: Duration(seconds: Random().nextInt(3) + 3))
      ..forward().then((value) {
        if (mounted) dispose();
      });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return Positioned(
          bottom: _controller.value * MediaQuery.of(context).size.height,
          left: leftOffset + (sin(_controller.value * 5) * 20),
          child: Opacity(
            opacity: 1.0 - _controller.value,
            child: Icon(Icons.favorite, color: Colors.pink.withOpacity(0.6), size: size),
          ),
        );
      },
    );
  }
}
