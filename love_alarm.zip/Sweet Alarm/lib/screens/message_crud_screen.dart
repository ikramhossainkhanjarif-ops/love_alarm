import 'package:flutter/material.dart';
import '../services/storage_service.dart';

class MessageCrudScreen extends StatefulWidget {
  const MessageCrudScreen({Key? key}) : super(key: key);
  @override
  _MessageCrudScreenState createState() => _MessageCrudScreenState();
}

class _MessageCrudScreenState extends State<MessageCrudScreen> {
  List<String> _messages = [];
  final TextEditingController _controller = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    var list = await StorageService.loadMessages();
    setState(() => _messages = list);
  }

  void _openEditor({int? index}) {
    if (index != null) _controller.text = _messages[index];
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(index == null ? "Add Message" : "Edit Message"),
        content: TextField(controller: _controller, maxLines: 3),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text("Cancel")),
          ElevatedButton(
            onPressed: () async {
              if (_controller.text.isNotEmpty) {
                if (index == null) _messages.add(_controller.text);
                else _messages[index] = _controller.text;
                await StorageService.saveMessages(_messages);
                _controller.clear();
                Navigator.pop(context);
                _loadData();
              }
            },
            child: const Text("Save"),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Manage Messages"), backgroundColor: Colors.pink[100]),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.pink,
        onPressed: () => _openEditor(),
        child: const Icon(Icons.add),
      ),
      body: ListView.builder(
        itemCount: _messages.length,
        itemBuilder: (context, idx) => ListTile(
          title: Text(_messages[idx]),
          trailing: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              IconButton(icon: const Icon(Icons.edit, color: Colors.blue), onPressed: () => _openEditor(index: idx)),
              IconButton(
                icon: const Icon(Icons.delete, color: Colors.red),
                onPressed: () async {
                  _messages.removeAt(idx);
                  await StorageService.saveMessages(_messages);
                  _loadData();
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
