class AlarmModel {
  final int id;
  final int hour;
  final int minute;
  final bool isActive;

  AlarmModel({
    required this.id,
    required this.hour,
    required this.minute,
    this.isActive = true,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'hour': hour,
        'minute': minute,
        'isActive': isActive,
      };

  factory AlarmModel.fromMap(Map<String, dynamic> map) => AlarmModel(
        id: map['id'],
        hour: map['hour'],
        minute: map['minute'],
        isActive: map['isActive'] ?? true,
      );
}
