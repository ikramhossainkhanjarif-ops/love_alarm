import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/alarm_model.dart';
import '../utils/default_messages.dart';

class StorageService {
  static const String _alarmKey = 'user_alarm';
  static const String _usedIndicesKey = 'used_msg_indices';

  static Future<void> saveAlarm(AlarmModel alarm) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_alarmKey, jsonEncode(alarm.toMap()));
  }

  static Future<AlarmModel?> getAlarm() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString(_alarmKey);
    if (data == null) return null;
    return AlarmModel.fromMap(jsonDecode(data));
  }

  static Future<File> _getLocalFile() async {
    final directory = await getApplicationDocumentsDirectory();
    return File('${directory.path}/romantic_messages.json');
  }

  static Future<List<String>> loadMessages() async {
    try {
      final file = await _getLocalFile();
      if (!await file.exists()) return DefaultMessages.list;
      final contents = await file.readAsString();
      List<dynamic> jsonList = jsonDecode(contents);
      return jsonList.cast<String>();
    } catch (e) {
      return DefaultMessages.list;
    }
  }

  static Future<void> saveMessages(List<String> messages) async {
    final file = await _getLocalFile();
    await file.writeAsString(jsonEncode(messages));
  }

  static Future<String> getRandomMessage() async {
    final prefs = await SharedPreferences.getInstance();
    List<String> messages = await loadMessages();
    List<String> usedStr = prefs.getStringList(_usedIndicesKey) ?? [];
    
    if (usedStr.length >= messages.length) {
      usedStr.clear();
    }

    List<int> usedIndices = usedStr.map(int.parse).toList();
    List<int> availableIndices = [];
    
    for (int i = 0; i < messages.length; i++) {
      if (!usedIndices.contains(i)) availableIndices.add(i);
    }

    int randomIndex = availableIndices[Random().nextInt(availableIndices.length)];
    usedStr.add(randomIndex.toString());
    await prefs.setStringList(_usedIndicesKey, usedStr);

    return messages[randomIndex];
  }
}
